import { ObjectId } from "mongodb";
import { Media } from "./Media";






export class Tag {
    _id: ObjectId;
    title: string;
    subtitle: string;
    description: string;
    iconURL: string;
    media: Media[];
    constructor(data: Tag) {
        if (data) {
            return Object.assign(this, data);
        }
    }
}
