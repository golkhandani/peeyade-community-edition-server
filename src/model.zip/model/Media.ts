import { MediaType } from "@enum/MediaType";
import { ContentWriter } from "./ContentWriter";






export class Media {
    type: MediaType;
    url: string;
    thumbnail?: Media;
    width: number;
    height: number;
    title?: string;
    description?: string;
    contentWriter?: ContentWriter;
    constructor(data: Media) {
        if (data) {
            return Object.assign(this, data);
        }
    }
}
