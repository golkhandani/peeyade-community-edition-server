
export type MetaTag = string;
