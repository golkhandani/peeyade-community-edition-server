import { PivotType } from "@enum/PivotType";
import { Exclude, Expose, Type } from "class-transformer";
import { IsDefined, ValidateNested } from "class-validator";
import { ObjectId } from "mongodb";
import { Address } from "./Address";
import { Attribute } from "./Attribute";
import { Contact } from "./Contact";
import { Content } from "./Content";
import { ContentWriter } from "./ContentWriter";
import { Media } from "./Media";
import { MetaTag } from "./MetaTag";
import { Rate } from "./Rate";
import { Status } from "./Status";
import { Tag } from "./Tag";

// ! createIndex( { "$**": "text" } )

@Exclude()
export class Pivot {
    @Expose()
    @Type(() => String)
    @IsDefined()
    _id: ObjectId;

    @Expose()
    type: PivotType; //! index

    @Expose()
    status: Status; //! index

    @Expose()
    title: string;

    @Expose()
    subtitle: string;

    @Expose()
    slug: string; //! index

    @Expose()
    description: string;

    @Expose()
    @Type(() => Media)
    media: Media[];

    @Expose()
    content: Content[];

    @Expose()
    tags: Tag[]; //! index

    @Expose()
    metaTags: MetaTag[];

    @Expose()
    note?: string;



    // Place
    @Expose()
    contacts: Contact[];

    @Expose()
    rates: Rate[];

    @Expose()
    @Type(() => ContentWriter)
    @ValidateNested()
    contentWriter: ContentWriter;

    @Expose()
    discoverer?: ContentWriter;

    @Expose()
    address: Address;

    @Expose()
    attributes: Attribute[];

    @Expose()
    likeCount: number;

    @Expose()
    saveCount: number;

    @Expose()
    shareCount: number;

    @Expose()
    viewCount: number;

    @Expose()
    createdAt: Date;

    updatedAt: Date;

    deletedAt: Date;

    __v: number;

    constructor(data: Pivot) {
        if (data) {
            return Object.assign(this, data);
        }
    }

};
