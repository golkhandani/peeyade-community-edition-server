import { MongoLocation } from "./MongoLocation";






export class Address {
    location: MongoLocation;
    city: string;
    state: string;
    country: string;
    street: string;
    neighborhood: string;
    detail?: string;
    constructor(data: Address) {
        if (data) {
            return Object.assign(this, data);
        }
    }
}
